from distutils.core import setup
import py2app

setup(
    app=['CurrencyConverter.py'],
    data_files=['MainMenu.nib'],
)
