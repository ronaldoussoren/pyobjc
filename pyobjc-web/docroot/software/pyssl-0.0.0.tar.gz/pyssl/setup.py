#!/usr/bin/env python

from distutils.core import setup, Extension
import os
import sys

orig = "/usr/lib/python2.2/lib-dynload/_socket.so"

try:
    setup (name = "pyssl",
           version = "2.2.1",
           description = "socket module w/ssl enabled",
           author = "bbum (not really)",
           author_email = "bbum@codefab.com",
	   url = "http://www.python.org",
           ext_modules = [
            Extension('_socket', ['socketmodule.c'],
                                   include_dirs = ["/usr/include/openssl"],
                                   library_dirs = ["/usr/lib/"],
                                   libraries = ['ssl', 'crypto'],
                                   define_macros = [('USE_SSL',1)] )
            ]
           )
    if os.path.exists(orig):
        os.rename(orig, "%s-original-non-ssl" % orig)
except:
    import sys
    import traceback
    traceback.print_exc()
    sys.exit(1)
