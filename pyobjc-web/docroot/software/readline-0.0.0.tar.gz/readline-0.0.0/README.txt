A very basic python module that simply builds/installs the readline module linking against the private readline.framework.  Can be used to add interactive readline support to the default python installation on OS X.

readline.c is the verbatum, unmodified source file from Python 2.2.1's src/Modules directory.  setup.py is just a quick hack to make it work.

To install:

   sudo /usr/bin/python setup.py install

(The explicit use of /usr/bin/python prevents conflicts with, say, a fink installed python).

b.bum
bbum@codefab.com
